UKCRASHREPORTER
---------------

For directions on using this class, see the comment in the header file.


LICENSE:

(c) 2006-08 by M. Uli Kusterer. You may redistribute, modify, use in
commercial products free of charge, however distributing modified copies
requires that you clearly mark them as having been modified by you, while
maintaining the original markings and copyrights. I don't like getting bug
reports about code I wasn't involved in.

I'd also appreciate if you gave credit in your app's about screen or a similar
place. A simple "Thanks to M. Uli Kusterer" is quite sufficient.
Also, I rarely turn down any postcards, gifts, complementary copies of
applications etc.

REVISION HISTORY:

0.1 - Initial public release.
0.2 - Made this support Leopard crash reports, added system info, integrated this with UKFeedbackProvider, added text field so user can provide additional information.
0.3 - Added missing UKSystemInfo, fixed a little bug for people on Leopard with old Tiger crashlogs.


CONTACT:
Get the newest version at http://www.zathras.de
E-Mail me at witness (at) zathras (dot) de or kusterer (at) gmail (dot) com
